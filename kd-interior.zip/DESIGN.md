# Design Brief — KD INTERIOR

**Purpose & Context**: Premium portfolio website for KD INTERIOR, a local false ceiling design specialist emphasizing direct craftsmanship, no brokers, direct client relationships.

**Tone**: Refined luxury with warmth — sophisticated yet approachable, editorial over corporate, gallery-first.

**Palette**: Warm neutral base (taupe 0.98 L 0.01 C 56 H) + burnt sienna accent (0.56 L 0.16 C 30 H) + deep charcoal foreground (0.2 L 0.01 C 56 H). Warmth through hue, not saturation.

**Typography**: Fraunces (serif display, elegant) + DM Sans (clean body, modern), Geist Mono (technical fallback).

**Elevation & Depth**: Soft shadows (subtle card effect), generous whitespace, layered card styling with warm tones, portfolio images as primary visual.

**Structural Zones**:
- Header: `bg-card` border-b, warm taupe card background with burnt sienna text for logo
- Hero: `bg-background` with large display type, centered, max-width container
- Gallery Grid: `bg-background`, 3-column grid (responsive), image cards with `shadow-card`
- Services: `bg-muted/20`, 3-column card layout with subtle backgrounds
- CTA Section: `bg-primary` (burnt sienna), centered white text, direct contact emphasis
- Footer: `bg-card` border-t, minimal typography, links in secondary tone

**Spacing & Rhythm**: 16px/24px base rhythm, generous gaps (gap-6 to gap-8), asymmetric column widths for editorial feel.

**Component Patterns**: Portfolio images use `portfolio-image` utility (shadow, hover lift). Buttons use primary/secondary semantic tokens. Text hierarchy through display vs body fonts and weight.

**Motion**: Smooth transitions (0.3s ease-out) on hover, image shadow lift, no animation bouncing.

**Constraints**: Light mode primary, no dark mode toggle (editorial simplicity), container max-5xl, warm material palette only, no neon/high-saturation accents.

**Signature Detail**: Portfolio images are the hero — not testimonials or copy. Subtle burnt sienna underlines and hover effects on interactive elements. Warm whitespace creates breathing room for image focus.
