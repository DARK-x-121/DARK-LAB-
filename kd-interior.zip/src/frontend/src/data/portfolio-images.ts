export interface PortfolioImage {
  index: number;
  title: string;
  path: string;
  category: string;
}

export const portfolioImages: PortfolioImage[] = [
  {
    index: 1,
    title: "False Ceiling Design 1",
    path: "/assets/img-20260421-wa0020-019dbf58-47b7-751d-90a7-eb571fdf2d97.jpg",
    category: "False Ceiling",
  },
  {
    index: 2,
    title: "False Ceiling Design 2",
    path: "/assets/img-20260421-wa0021-019dbf58-4d4b-773d-8a28-80f1771a1a77.jpg",
    category: "False Ceiling",
  },
  {
    index: 3,
    title: "False Ceiling Design 3",
    path: "/assets/img-20260421-wa0022-019dbf58-49da-7220-a8e9-3423dc24c991.jpg",
    category: "False Ceiling",
  },
  {
    index: 4,
    title: "False Ceiling Design 4",
    path: "/assets/img-20260421-wa0025-019dbf58-4d24-76f2-b8c3-fef5e76b5f70.jpg",
    category: "False Ceiling",
  },
  {
    index: 5,
    title: "False Ceiling Design 5",
    path: "/assets/img-20260421-wa0026-019dbf58-4d1d-724a-9cb4-1f4f8cb7a1f6.jpg",
    category: "False Ceiling",
  },
  {
    index: 6,
    title: "False Ceiling Design 6",
    path: "/assets/img-20260421-wa0027-019dbf58-4ce3-73fc-a83b-b13c5a5872da.jpg",
    category: "False Ceiling",
  },
  {
    index: 7,
    title: "False Ceiling Design 7",
    path: "/assets/img-20260421-wa0028-019dbf58-483d-7268-b733-ce2bb17ce99b.jpg",
    category: "False Ceiling",
  },
  {
    index: 8,
    title: "False Ceiling Design 8",
    path: "/assets/img-20260421-wa0030-019dbf58-458c-746e-abdf-35c781a19a31.jpg",
    category: "False Ceiling",
  },
  {
    index: 9,
    title: "False Ceiling Design 9",
    path: "/assets/img-20260421-wa0031-019dbf58-493d-7141-9c62-095315082978.jpg",
    category: "False Ceiling",
  },
  {
    index: 10,
    title: "False Ceiling Design 10",
    path: "/assets/img-20260421-wa0032-019dbf58-49f8-7643-93eb-5e0f23c6c328.jpg",
    category: "False Ceiling",
  },
];

export default portfolioImages;
