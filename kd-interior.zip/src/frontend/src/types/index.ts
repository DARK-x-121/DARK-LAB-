export interface NavItem {
  label: string;
  href: string;
}

export interface Service {
  id: string;
  icon: string;
  title: string;
  description: string;
  features: string[];
}

export interface PortfolioItem {
  id: string;
  title: string;
  location: string;
  category: string;
  imagePath: string;
  featured?: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  rating: number;
  text: string;
}

export interface ContactInfo {
  phone: string;
  facebook: string;
  tagline: string;
}
