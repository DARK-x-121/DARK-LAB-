import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { portfolioImages } from "@/data/portfolio-images";
import {
  Award,
  ChevronLeft,
  ChevronRight,
  Hammer,
  Lightbulb,
  Palette,
  Phone,
  ShieldCheck,
  Star,
  Users,
  X,
} from "lucide-react";
import { useState } from "react";
import { SiFacebook } from "react-icons/si";

// ─── Hero ────────────────────────────────────────────────────────────────────

function Hero() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background image + overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            "url('/assets/img-20260421-wa0030-019dbf58-458c-746e-abdf-35c781a19a31.jpg')",
        }}
        aria-hidden="true"
      />
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(135deg, oklch(0.12 0.04 30 / 0.88) 0%, oklch(0.18 0.06 34 / 0.78) 50%, oklch(0.14 0.05 28 / 0.85) 100%)",
        }}
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-10 container-tight w-full text-center px-4">
        {/* Trust badge */}
        <div className="flex justify-center mb-6" data-ocid="hero.trust_badge">
          <Badge
            className="text-sm font-body font-semibold px-5 py-2 tracking-wide border-0"
            style={{
              background: "oklch(0.56 0.16 30 / 0.9)",
              color: "oklch(0.98 0 0)",
            }}
          >
            No Broker &bull; No Middleman &bull; Direct Work
          </Badge>
        </div>

        {/* Headline */}
        <h1
          className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-5"
          style={{ color: "oklch(0.98 0 0)" }}
        >
          Transform Your Space
          <br />
          <span style={{ color: "oklch(0.78 0.12 46)" }}>with KD INTERIOR</span>
        </h1>

        {/* Subheadline */}
        <p
          className="font-body text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
          style={{ color: "oklch(0.88 0.02 56)" }}
        >
          Premium false ceiling designs that blend artistry with craftsmanship —
          straight from expert hands to your home.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            type="button"
            size="lg"
            onClick={() => scrollTo("portfolio")}
            className="font-body font-semibold text-base px-8 py-6 transition-smooth hover:scale-105"
            style={{
              background: "oklch(0.56 0.16 30)",
              color: "oklch(0.98 0 0)",
            }}
            data-ocid="hero.view_work_button"
          >
            View Our Work
          </Button>
          <Button
            type="button"
            size="lg"
            variant="outline"
            asChild
            className="font-body font-semibold text-base px-8 py-6 transition-smooth hover:scale-105 border-2"
            style={{
              borderColor: "oklch(0.98 0 0 / 0.7)",
              color: "oklch(0.98 0 0)",
              background: "oklch(0.98 0 0 / 0.08)",
            }}
          >
            <a href="tel:+916290365684" data-ocid="hero.call_button">
              <Phone className="mr-2 h-5 w-5" />
              Call Us Now
            </a>
          </Button>
        </div>

        {/* Scroll cue */}
        <div className="mt-16 flex justify-center" aria-hidden="true">
          <div
            className="w-6 h-10 rounded-full border-2 flex items-start justify-center p-1"
            style={{ borderColor: "oklch(0.98 0 0 / 0.4)" }}
          >
            <div
              className="w-1 h-2 rounded-full animate-bounce"
              style={{ background: "oklch(0.98 0 0 / 0.6)" }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── About / Trust ───────────────────────────────────────────────────────────

const trustPoints = [
  {
    icon: ShieldCheck,
    title: "Direct Service",
    desc: "No brokers, no agents. You deal directly with us for transparent pricing and honest work.",
  },
  {
    icon: Users,
    title: "Expert Craftsmanship",
    desc: "Years of experience delivering premium false ceiling designs across homes and commercial spaces.",
  },
  {
    icon: Star,
    title: "Personal Touch",
    desc: "Every project treated with individual care. Your vision drives our design and execution.",
  },
];

function About() {
  return (
    <section
      id="about"
      className="section-spacing"
      style={{ background: "oklch(0.97 0.02 56)" }}
    >
      <div className="container-tight">
        <div className="text-center mb-12">
          <p
            className="font-body text-sm font-semibold uppercase tracking-widest mb-3"
            style={{ color: "oklch(0.56 0.16 30)" }}
          >
            Our Promise
          </p>
          <h2
            className="font-display text-3xl md:text-4xl lg:text-5xl font-bold"
            style={{ color: "oklch(0.2 0.01 56)" }}
          >
            Why Choose KD INTERIOR?
          </h2>
        </div>

        <div
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
          data-ocid="about.cards_list"
        >
          {trustPoints.map((point, i) => {
            const Icon = point.icon;
            return (
              <div
                key={point.title}
                className="rounded-2xl p-8 flex flex-col items-start gap-4 transition-smooth hover:-translate-y-1 hover:shadow-lg"
                style={{
                  background: "oklch(0.99 0.01 56)",
                  border: "1px solid oklch(0.93 0.02 56)",
                }}
                data-ocid={`about.card.${i + 1}`}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: "oklch(0.56 0.16 30 / 0.1)" }}
                >
                  <Icon
                    className="w-6 h-6"
                    style={{ color: "oklch(0.56 0.16 30)" }}
                  />
                </div>
                <h3
                  className="font-display text-xl font-bold"
                  style={{ color: "oklch(0.2 0.01 56)" }}
                >
                  {point.title}
                </h3>
                <p
                  className="font-body text-sm leading-relaxed"
                  style={{ color: "oklch(0.45 0.01 56)" }}
                >
                  {point.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ─── Portfolio Gallery ────────────────────────────────────────────────────────

function Portfolio() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const openLightbox = (index: number) => setLightboxIndex(index);
  const closeLightbox = () => setLightboxIndex(null);
  const prevImage = () =>
    setLightboxIndex((i) =>
      i === null
        ? null
        : (i - 1 + portfolioImages.length) % portfolioImages.length,
    );
  const nextImage = () =>
    setLightboxIndex((i) =>
      i === null ? null : (i + 1) % portfolioImages.length,
    );

  const currentImage =
    lightboxIndex !== null ? portfolioImages[lightboxIndex] : null;

  return (
    <section id="portfolio" className="section-spacing bg-background">
      <div className="container-tight">
        <div className="text-center mb-12">
          <p
            className="font-body text-sm font-semibold uppercase tracking-widest mb-3"
            style={{ color: "oklch(0.56 0.16 30)" }}
          >
            Portfolio
          </p>
          <h2
            className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            style={{ color: "oklch(0.2 0.01 56)" }}
          >
            Our Work
          </h2>
          <p
            className="font-body text-base max-w-lg mx-auto"
            style={{ color: "oklch(0.45 0.01 56)" }}
          >
            Explore our collection of stunning false ceiling designs — every
            project unique, every ceiling a masterpiece.
          </p>
        </div>

        <div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
          data-ocid="portfolio.grid"
        >
          {portfolioImages.map((img, i) => (
            <button
              key={img.path}
              type="button"
              onClick={() => openLightbox(i)}
              className="group relative portfolio-image aspect-[4/3] w-full text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              data-ocid={`portfolio.item.${i + 1}`}
              aria-label={`View ${img.title}`}
            >
              <img
                src={img.path}
                alt={img.title}
                className="w-full h-full object-cover transition-smooth group-hover:scale-105"
                loading="lazy"
              />
              {/* Hover overlay */}
              <div
                className="absolute inset-0 flex items-end p-4 opacity-0 group-hover:opacity-100 transition-smooth rounded-lg"
                style={{
                  background:
                    "linear-gradient(to top, oklch(0.12 0.04 30 / 0.85) 0%, transparent 60%)",
                }}
              >
                <span
                  className="font-body font-semibold text-sm"
                  style={{ color: "oklch(0.98 0 0)" }}
                >
                  {img.title}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      <Dialog
        open={lightboxIndex !== null}
        onOpenChange={(open) => !open && closeLightbox()}
      >
        <DialogContent
          className="max-w-4xl p-0 overflow-hidden border-0"
          style={{ background: "oklch(0.1 0.02 30)" }}
          data-ocid="portfolio.dialog"
        >
          <div className="relative">
            {currentImage && (
              <img
                src={currentImage.path}
                alt={currentImage.title}
                className="w-full max-h-[80vh] object-contain"
              />
            )}

            {/* Close */}
            <button
              type="button"
              onClick={closeLightbox}
              className="absolute top-3 right-3 w-9 h-9 rounded-full flex items-center justify-center transition-smooth hover:scale-110"
              style={{ background: "oklch(0.98 0 0 / 0.15)" }}
              aria-label="Close lightbox"
              data-ocid="portfolio.close_button"
            >
              <X className="w-5 h-5" style={{ color: "oklch(0.98 0 0)" }} />
            </button>

            {/* Prev */}
            <button
              type="button"
              onClick={prevImage}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center transition-smooth hover:scale-110"
              style={{ background: "oklch(0.98 0 0 / 0.15)" }}
              aria-label="Previous image"
              data-ocid="portfolio.lightbox_prev"
            >
              <ChevronLeft
                className="w-6 h-6"
                style={{ color: "oklch(0.98 0 0)" }}
              />
            </button>

            {/* Next */}
            <button
              type="button"
              onClick={nextImage}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center transition-smooth hover:scale-110"
              style={{ background: "oklch(0.98 0 0 / 0.15)" }}
              aria-label="Next image"
              data-ocid="portfolio.lightbox_next"
            >
              <ChevronRight
                className="w-6 h-6"
                style={{ color: "oklch(0.98 0 0)" }}
              />
            </button>

            {/* Caption */}
            {currentImage && (
              <div
                className="absolute bottom-0 left-0 right-0 px-6 py-4"
                style={{
                  background:
                    "linear-gradient(to top, oklch(0.1 0.02 30 / 0.9) 0%, transparent 100%)",
                }}
              >
                <p
                  className="font-body font-semibold text-base"
                  style={{ color: "oklch(0.98 0 0)" }}
                >
                  {currentImage.title}
                </p>
                <p
                  className="font-body text-sm"
                  style={{ color: "oklch(0.78 0.02 56)" }}
                >
                  {lightboxIndex !== null ? lightboxIndex + 1 : ""} /{" "}
                  {portfolioImages.length}
                </p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}

// ─── Services ────────────────────────────────────────────────────────────────

const services = [
  {
    icon: Lightbulb,
    title: "Modern Designs",
    desc: "Contemporary false ceiling patterns with integrated LED lighting for dramatic ambiance.",
  },
  {
    icon: Palette,
    title: "Custom Solutions",
    desc: "Every ceiling tailored to your unique space, style preferences, and budget.",
  },
  {
    icon: Award,
    title: "Quality Materials",
    desc: "Only premium gypsum, PVC, and acoustic materials — built to last and look stunning.",
  },
  {
    icon: Hammer,
    title: "Professional Work",
    desc: "Skilled craftsmen, clean execution, zero mess — your home treated with respect.",
  },
];

function Services() {
  return (
    <section
      id="services"
      className="section-spacing"
      style={{ background: "oklch(0.97 0.02 56)" }}
    >
      <div className="container-tight">
        <div className="text-center mb-12">
          <p
            className="font-body text-sm font-semibold uppercase tracking-widest mb-3"
            style={{ color: "oklch(0.56 0.16 30)" }}
          >
            Services
          </p>
          <h2
            className="font-display text-3xl md:text-4xl lg:text-5xl font-bold"
            style={{ color: "oklch(0.2 0.01 56)" }}
          >
            What We Offer
          </h2>
        </div>

        <div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5"
          data-ocid="services.list"
        >
          {services.map((service, i) => {
            const Icon = service.icon;
            return (
              <div
                key={service.title}
                className="rounded-2xl p-7 flex flex-col gap-4 transition-smooth hover:-translate-y-2 hover:shadow-xl cursor-default"
                style={{
                  background: "oklch(0.99 0.01 56)",
                  border: "1px solid oklch(0.93 0.02 56)",
                }}
                data-ocid={`services.card.${i + 1}`}
              >
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center"
                  style={{ background: "oklch(0.56 0.16 30 / 0.1)" }}
                >
                  <Icon
                    className="w-5 h-5"
                    style={{ color: "oklch(0.56 0.16 30)" }}
                  />
                </div>
                <h3
                  className="font-display text-lg font-bold leading-tight"
                  style={{ color: "oklch(0.2 0.01 56)" }}
                >
                  {service.title}
                </h3>
                <p
                  className="font-body text-sm leading-relaxed"
                  style={{ color: "oklch(0.45 0.01 56)" }}
                >
                  {service.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ─── Contact ─────────────────────────────────────────────────────────────────

function Contact() {
  return (
    <section
      id="contact"
      className="section-spacing"
      style={{
        background:
          "linear-gradient(135deg, oklch(0.38 0.12 30) 0%, oklch(0.28 0.09 28) 50%, oklch(0.32 0.10 32) 100%)",
      }}
    >
      <div className="container-tight text-center">
        <p
          className="font-body text-sm font-semibold uppercase tracking-widest mb-3"
          style={{ color: "oklch(0.78 0.10 46)" }}
        >
          Contact Us
        </p>
        <h2
          className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-5"
          style={{ color: "oklch(0.98 0 0)" }}
        >
          Get in Touch
        </h2>
        <p
          className="font-body text-base md:text-lg max-w-xl mx-auto mb-12"
          style={{ color: "oklch(0.88 0.02 56)" }}
        >
          Ready to transform your ceiling? Contact us directly — no middlemen,
          no delays, no hidden charges.
        </p>

        {/* Contact cards */}
        <div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto mb-10"
          data-ocid="contact.cards"
        >
          {/* Phone */}
          <div
            className="rounded-2xl p-8 flex flex-col items-center gap-5 transition-smooth hover:-translate-y-1 hover:shadow-2xl"
            style={{
              background: "oklch(0.98 0 0 / 0.08)",
              border: "1px solid oklch(0.98 0 0 / 0.15)",
            }}
            data-ocid="contact.phone_card"
          >
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center"
              style={{ background: "oklch(0.56 0.16 30 / 0.3)" }}
            >
              <Phone
                className="w-7 h-7"
                style={{ color: "oklch(0.9 0.06 46)" }}
              />
            </div>
            <div>
              <p
                className="font-body text-sm font-semibold uppercase tracking-wide mb-1"
                style={{ color: "oklch(0.78 0.10 46)" }}
              >
                Call Directly
              </p>
              <p
                className="font-display text-2xl font-bold"
                style={{ color: "oklch(0.98 0 0)" }}
              >
                +91 62903 65684
              </p>
            </div>
            <Button
              type="button"
              size="lg"
              className="w-full font-body font-semibold transition-smooth hover:scale-105"
              style={{
                background: "oklch(0.56 0.16 30)",
                color: "oklch(0.98 0 0)",
              }}
              asChild
            >
              <a href="tel:+916290365684" data-ocid="contact.call_button">
                <Phone className="mr-2 h-5 w-5" />
                Call Now
              </a>
            </Button>
          </div>

          {/* Facebook */}
          <div
            className="rounded-2xl p-8 flex flex-col items-center gap-5 transition-smooth hover:-translate-y-1 hover:shadow-2xl"
            style={{
              background: "oklch(0.98 0 0 / 0.08)",
              border: "1px solid oklch(0.98 0 0 / 0.15)",
            }}
            data-ocid="contact.facebook_card"
          >
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center"
              style={{ background: "oklch(0.5 0.18 260 / 0.25)" }}
            >
              <SiFacebook
                className="w-7 h-7"
                style={{ color: "oklch(0.72 0.14 260)" }}
              />
            </div>
            <div>
              <p
                className="font-body text-sm font-semibold uppercase tracking-wide mb-1"
                style={{ color: "oklch(0.78 0.10 46)" }}
              >
                Facebook Page
              </p>
              <p
                className="font-display text-2xl font-bold"
                style={{ color: "oklch(0.98 0 0)" }}
              >
                KD INTERIOR
              </p>
            </div>
            <Button
              type="button"
              size="lg"
              className="w-full font-body font-semibold transition-smooth hover:scale-105"
              style={{
                background: "oklch(0.45 0.18 260)",
                color: "oklch(0.98 0 0)",
              }}
              asChild
            >
              <a
                href="https://www.facebook.com/search/top?q=KD%20INTERIOR"
                target="_blank"
                rel="noopener noreferrer"
                data-ocid="contact.facebook_button"
              >
                <SiFacebook className="mr-2 h-5 w-5" />
                Message on Facebook
              </a>
            </Button>
          </div>
        </div>

        {/* Warm CTA note */}
        <div
          className="inline-flex items-center gap-2 rounded-full px-6 py-3"
          style={{
            background: "oklch(0.98 0 0 / 0.1)",
            border: "1px solid oklch(0.98 0 0 / 0.15)",
          }}
          data-ocid="contact.cta_note"
        >
          <ShieldCheck
            className="w-4 h-4 flex-shrink-0"
            style={{ color: "oklch(0.78 0.10 46)" }}
          />
          <p
            className="font-body text-sm"
            style={{ color: "oklch(0.88 0.02 56)" }}
          >
            We respond quickly and give you a direct quote — no agents involved.
          </p>
        </div>
      </div>
    </section>
  );
}

// ─── HomePage ─────────────────────────────────────────────────────────────────

export function HomePage() {
  return (
    <>
      <Hero />
      <About />
      <Portfolio />
      <Services />
      <Contact />
    </>
  );
}
