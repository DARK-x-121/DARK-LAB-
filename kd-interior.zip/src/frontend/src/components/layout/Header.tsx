import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import type { NavItem } from "@/types";
import { Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";

const navItems: NavItem[] = [
  { label: "Home", href: "#home" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Services", href: "#services" },
  { label: "Contact", href: "#contact" },
];

function scrollTo(href: string) {
  const id = href.replace("#", "");
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: "smooth" });
}

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (href: string) => {
    scrollTo(href);
    setMobileOpen(false);
  };

  return (
    <header
      data-ocid="header"
      className={[
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-card/95 backdrop-blur-md border-b border-border shadow-sm"
          : "bg-transparent",
      ].join(" ")}
    >
      <div className="container-tight flex items-center justify-between h-16 md:h-20">
        {/* Logo */}
        <button
          type="button"
          onClick={() => scrollTo("#home")}
          className="flex items-center gap-1.5 group"
          aria-label="KD INTERIOR – Home"
          data-ocid="header.logo"
        >
          <span className="font-display font-black text-xl md:text-2xl tracking-tight">
            <span className="text-accent">KD</span>
            <span className="text-foreground ml-1.5">INTERIOR</span>
          </span>
        </button>

        {/* Desktop Nav */}
        <nav
          className="hidden md:flex items-center gap-8"
          aria-label="Main navigation"
        >
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => {
                e.preventDefault();
                scrollTo(item.href);
              }}
              className="text-sm font-body font-medium text-muted-foreground hover:text-accent transition-colors duration-200 relative after:absolute after:bottom-[-2px] after:left-0 after:h-[1.5px] after:w-0 after:bg-accent after:transition-all after:duration-300 hover:after:w-full"
              data-ocid={`header.nav.${item.label.toLowerCase()}`}
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* CTA Phone */}
        <div className="hidden md:flex items-center gap-3">
          <Button
            asChild
            variant="outline"
            size="sm"
            className="border-accent/40 text-accent hover:bg-accent hover:text-accent-foreground transition-smooth font-medium"
            data-ocid="header.phone_button"
          >
            <a href="tel:+916290365684" aria-label="Call KD INTERIOR">
              <Phone className="w-3.5 h-3.5 mr-1.5" />
              +91 62903 65684
            </a>
          </Button>
        </div>

        {/* Mobile Menu */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-foreground"
              aria-label="Open menu"
              data-ocid="header.mobile_menu_button"
            >
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent
            side="right"
            className="w-72 bg-card border-border"
            data-ocid="header.mobile_menu"
          >
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between mb-8 pt-2">
                <span className="font-display font-black text-xl">
                  <span className="text-accent">KD</span>
                  <span className="text-foreground ml-1.5">INTERIOR</span>
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setMobileOpen(false)}
                  aria-label="Close menu"
                  data-ocid="header.mobile_menu.close_button"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <nav
                className="flex flex-col gap-1"
                aria-label="Mobile navigation"
              >
                {navItems.map((item) => (
                  <button
                    type="button"
                    key={item.href}
                    onClick={() => handleNav(item.href)}
                    className="text-left px-4 py-3 text-base font-medium text-foreground hover:text-accent hover:bg-muted rounded-lg transition-smooth"
                    data-ocid={`header.mobile_nav.${item.label.toLowerCase()}`}
                  >
                    {item.label}
                  </button>
                ))}
              </nav>

              <div className="mt-auto pb-6">
                <a
                  href="tel:+916290365684"
                  className="flex items-center gap-2 px-4 py-3 bg-accent text-accent-foreground rounded-lg font-medium text-sm transition-smooth hover:opacity-90"
                  data-ocid="header.mobile_phone_link"
                >
                  <Phone className="w-4 h-4" />
                  +91 62903 65684
                </a>
                <p className="text-xs text-muted-foreground mt-3 px-4">
                  No broker • No middleman • Direct work
                </p>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
