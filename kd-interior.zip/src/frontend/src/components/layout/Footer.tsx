import { Phone } from "lucide-react";
import { SiFacebook } from "react-icons/si";

export function Footer() {
  const year = new Date().getFullYear();
  const hostname =
    typeof window !== "undefined"
      ? encodeURIComponent(window.location.hostname)
      : "";
  const caffeineUrl = `https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${hostname}`;

  return (
    <footer data-ocid="footer" className="bg-card border-t border-border mt-0">
      {/* Direct Contact Banner */}
      <div className="bg-accent text-accent-foreground">
        <div className="container-tight py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-display font-semibold text-lg tracking-wide text-center sm:text-left">
            No Broker &bull; No Middleman &bull; Direct Work
          </p>
          <a
            href="tel:+916290365684"
            className="flex items-center gap-2 bg-accent-foreground/10 hover:bg-accent-foreground/20 text-accent-foreground font-medium px-5 py-2.5 rounded-lg transition-smooth text-sm border border-accent-foreground/20"
            data-ocid="footer.phone_link"
            aria-label="Call KD INTERIOR"
          >
            <Phone className="w-4 h-4" />
            +91 62903 65684
          </a>
        </div>
      </div>

      {/* Main Footer */}
      <div className="container-tight py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="space-y-3">
            <span className="font-display font-black text-2xl">
              <span className="text-accent">KD</span>
              <span className="text-foreground ml-1.5">INTERIOR</span>
            </span>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
              Premium false ceiling specialists crafting beautiful, functional
              spaces across Kolkata with precision and artistry.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h3 className="font-display font-semibold text-foreground text-sm uppercase tracking-widest">
              Quick Links
            </h3>
            <nav className="flex flex-col gap-2" aria-label="Footer navigation">
              {[
                { label: "Home", href: "#home" },
                { label: "Portfolio", href: "#portfolio" },
                { label: "Services", href: "#services" },
                { label: "Contact", href: "#contact" },
              ].map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={(e) => {
                    e.preventDefault();
                    document
                      .getElementById(item.href.slice(1))
                      ?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
                  data-ocid={`footer.nav.${item.label.toLowerCase()}`}
                >
                  {item.label}
                </a>
              ))}
            </nav>
          </div>

          {/* Contact & Social */}
          <div className="space-y-3">
            <h3 className="font-display font-semibold text-foreground text-sm uppercase tracking-widest">
              Get In Touch
            </h3>
            <a
              href="tel:+916290365684"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              data-ocid="footer.contact_phone"
            >
              <Phone className="w-4 h-4 text-accent" />
              +91 62903 65684
            </a>
            <a
              href="https://www.facebook.com/search/top?q=KD%20INTERIOR"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              data-ocid="footer.facebook_link"
              aria-label="KD INTERIOR on Facebook"
            >
              <SiFacebook className="w-4 h-4 text-accent" />
              KD INTERIOR on Facebook
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <p>&copy; {year} KD INTERIOR. All rights reserved.</p>
          <p>
            Built with love using{" "}
            <a
              href={caffeineUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-accent transition-colors duration-200"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
